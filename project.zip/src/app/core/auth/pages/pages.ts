import { Component } from '@angular/core';

@Component({
  selector: 'app-pages',
  imports: [],
  templateUrl: './pages.html',
  styleUrl: './pages.scss'
})
export class Pages {

}
