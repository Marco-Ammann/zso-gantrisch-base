import { Component } from '@angular/core';

@Component({
  selector: 'app-users-list',
  imports: [],
  templateUrl: './user-detail.html',
  styleUrl: './user-detail.scss'
})
export class UserDetail {

}
