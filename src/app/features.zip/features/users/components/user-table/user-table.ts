import { Component } from '@angular/core';

@Component({
  selector: 'app-user-table',
  imports: [],
  templateUrl: './user-table.html',
  styleUrl: './user-table.scss'
})
export class UserTable {

}
