import { Component } from '@angular/core';

@Component({
  selector: 'app-user-dialog',
  imports: [],
  templateUrl: './user-dialog.html',
  styleUrl: './user-dialog.scss'
})
export class UserDialog {

}
